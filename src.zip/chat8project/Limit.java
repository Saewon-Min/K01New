package chat8project;

public interface Limit {
	int MAX_ACCEPT = 3;
	
}
